const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'evolink-v06-'));
process.env.DATA_DIR = temp;
const {createServer} = require('../server');

test('v0.6: convite validado, entrada cross-device, link inválido, regeneração e persistência',async t=>{
  const server = createServer();
  await new Promise(r=>server.listen(0,'127.0.0.1',r));
  t.after(()=>new Promise(r=>server.close(r)));
  const origin='http://127.0.0.1:'+server.address().port;
  async function api(method,url,data,cookie){
    const res=await fetch(origin+url,{method,headers:{'Content-Type':'application/json',...(cookie?{cookie}:{})},...(method==='POST'?{body:JSON.stringify(data||{})}:{})});
    return {status:res.status,result:await res.json(),cookie:res.headers.get('set-cookie')?.split(';')[0]};
  }
  // Representa 3 aparelhos diferentes usando o MESMO servidor compartilhado.
  const mr=await api('POST','/api/register',{name:'Mestre Azul',username:'gm-online',password:'SenhaSegura123',role:'mestre'});
  assert.equal(mr.status,201);
  const c=await api('POST','/api/campaigns',{name:'Pokémon Evolution Online'},mr.cookie);
  assert.equal(c.status,201);
  const code=c.result.campaign.code;
  const info=await api('GET',`/api/invites/${code.toLowerCase()}`);
  assert.equal(info.status,200);
  assert.deepEqual(info.result.campaign,{name:'Pokémon Evolution Online',masterName:'Mestre Azul'});
  const invalid=await api('GET','/api/invites/AAAAAAA');
  assert.equal(invalid.status,404);
  const pr=await api('POST','/api/register',{name:'Treinador Verde',username:'player-online',password:'SenhaSegura456',role:'jogador'});
  const join=await api('POST','/api/campaigns/join',{code:code.toLowerCase()},pr.cookie);
  assert.equal(join.status,200);
  const me=await api('GET','/api/me',null,pr.cookie);
  assert.equal(me.result.campaigns.length,1);
  assert.equal(me.result.campaigns[0].name,'Pokémon Evolution Online');
  assert.equal(me.result.campaigns[0].code,undefined,'Código de convite fica visível apenas ao Mestre');
  const pr2=await api('POST','/api/register',{name:'Treinador Roxo',username:'player-online2',password:'SenhaSegura456',role:'jogador'});
  assert.equal((await api('POST','/api/campaigns/join',{code},pr2.cookie)).status,200);
  const changed=await api('POST',`/api/campaigns/${c.result.campaign.id}/reissue-code`,{},mr.cookie);
  assert.equal(changed.status,200);
  assert.notEqual(changed.result.campaign.code,code);
  assert.equal((await api('GET',`/api/invites/${code}`)).status,404);
  assert.equal((await api('GET',`/api/invites/${changed.result.campaign.code}`)).status,200);
  const persisted=JSON.parse(fs.readFileSync(path.join(temp,'evolink.json'),'utf8'));
  assert.equal(persisted.campaigns[0].memberIds.length,2);
  const ui=await fetch(origin+'/app.js');const js=await ui.text();
  assert.match(js,/Compartilhar convite/);
  assert.match(js,/\?convite=/);
  assert.match(js,/\/api\/invites\//);
});
