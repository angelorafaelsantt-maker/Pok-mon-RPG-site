const test=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');const os=require('node:os');const path=require('node:path');
const temp=fs.mkdtempSync(path.join(os.tmpdir(),'evolink-02-'));
// Este teste roda em processo separado para usar sua própria instância de dados.
process.env.DATA_DIR=temp;
const {createServer}=require('../server');
test('Pokédex v0.2: status, importação, imagens, edição e acesso',async t=>{
 const srv=createServer();await new Promise(resolve=>srv.listen(0,'127.0.0.1',resolve));t.after(()=>new Promise(r=>srv.close(r)));
 const base='http://127.0.0.1:'+srv.address().port;
 async function req(method,url,data,cookie=''){const r=await fetch(base+url,{method,headers:{'Content-Type':'application/json',...(cookie?{Cookie:cookie}:{})},...(data?{body:JSON.stringify(data)}:{})});return{code:r.status,json:await r.json(),cookie:r.headers.get('set-cookie')};}
 const gm=await req('POST','/api/register',{username:'pokemonmaster',name:'Mestre',password:'senhaBemForte123',role:'mestre'}),gc=gm.cookie.split(';')[0];
 const pl=await req('POST','/api/register',{username:'pokemonplayer',name:'Treinador',password:'senhaBemForte123',role:'jogador'}),pc=pl.cookie.split(';')[0];
 const campaign=(await req('POST','/api/campaigns',{name:'Pokédex Evolution'},gc)).json.campaign;
 await req('POST','/api/campaigns/join',{code:campaign.code},pc);
 const baseP={number:1,name:'Cedarbi',type1:'Grama',type2:'',category:'',inspirationCountry:'Marrocos',abilities:{primary:'Overgrow',secondary:'',hidden:''},stats:{hp:45,attack:49,defense:49,spAttack:65,spDefense:65,speed:45},evolvesTo:2,description:'Um Pokémon original.'};
 const add=await req('POST',`/api/campaigns/${campaign.id}/species`,baseP,gc);assert.equal(add.code,201);assert.equal(add.json.species.stats.hp,45);const sid=add.json.species.id;
 const denied=await req('POST',`/api/campaigns/${campaign.id}/species/${sid}/update`,baseP,pc);assert.equal(denied.code,403);
 const picture=Buffer.from('89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000b49444154789c636000020000050001a5f645400000000049454e44ae426082','hex');
 const up=await req('POST',`/api/campaigns/${campaign.id}/species/${sid}/image`,{variant:'normal',base64:picture.toString('base64')},gc);assert.equal(up.code,200);assert.match(up.json.species.images.normal,/species-media/);
 const imageResponse=await fetch(base+up.json.species.images.normal,{headers:{Cookie:pc}});assert.equal(imageResponse.status,404);// v0.4: imagens só são liberadas depois de encontro ou captura, mesmo em espécies públicas.
 const deniedImage=await req('POST',`/api/campaigns/${campaign.id}/species/${sid}/image`,{variant:'shiny',base64:picture.toString('base64')},pc);assert.equal(deniedImage.code,403);
 const update=await req('POST',`/api/campaigns/${campaign.id}/species/${sid}/update`,{...baseP,visibleToPlayers:false},gc);assert.equal(update.code,200);
 const playerMe=await req('GET','/api/me',null,pc);assert.equal(playerMe.json.species.length,0);assert.equal(playerMe.json.campaigns[0].speciesCount,0);
 const privateImage=await fetch(base+up.json.species.images.normal,{headers:{Cookie:pc}});assert.equal(privateImage.status,404);
 const originalMe=await req('GET','/api/me',null,gc);assert.equal(originalMe.json.species.length,1);
 const importData={species:[{number:2,name:'Zellion',type1:'Grama',type2:'Psíquico',stats:{hp:null,attack:null,defense:null,spAttack:null,spDefense:null,speed:null}}]};
 const bulk=await req('POST',`/api/campaigns/${campaign.id}/species/import`,importData,gc);assert.equal(bulk.code,201);assert.equal(bulk.json.imported,1);
 const duplicate=await req('POST',`/api/campaigns/${campaign.id}/species/import`,importData,gc);assert.equal(duplicate.code,409);
 const badStats=await req('POST',`/api/campaigns/${campaign.id}/species`,{...baseP,number:3,name:'Novo',stats:{hp:300}},gc);assert.equal(badStats.code,400);
 const model=await fetch(base+'/pokedex-template.json');assert.equal(model.status,200);assert.ok(Array.isArray((await model.json()).species));
 const saved=JSON.parse(fs.readFileSync(path.join(temp,'evolink.json')));assert.equal(saved.species.length,2);
});
